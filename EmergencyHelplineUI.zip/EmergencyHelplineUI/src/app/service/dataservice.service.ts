import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import {
  ModelData,
  DistrictTalukPinCode,
  ApiResponse,
  ApiResponseArray
} from "../model/modeldata";
@Injectable({
  providedIn: 'root'
})
export class DataserviceService {

  constructor(private http: HttpClient) { }

  public getHospitalSearchResult(requestInput){
    return this.http.get<ApiResponseArray>("url");
  }
}
